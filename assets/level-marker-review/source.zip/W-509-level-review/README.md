# Level-marker export review fixture

Requires Node.js 20 or newer. No npm packages, engine project, network calls or production data are required.

```sh
node export-markers.mjs sample-level.json
node verify.mjs
python3 -m http.server 5202 --bind 127.0.0.1
```

Open `http://127.0.0.1:5202/` to view the grid and CSV. The first command writes CSV only to stdout. The verification helper writes local CSV and JSON evidence files.

The contract is an 8 × 6 grid with 32-unit cells, zero-based row/column indices, a top-left origin, X right and Y down, with coordinates at cell centers. The player, gate and pit export to `(48,144)`, `(208,48)` and `(144,144)`.

`node export-markers.mjs reject-level.json` deliberately exits 1 and emits no partial CSV. `verify.mjs` ran 14 checks and saved its report in `evidence/verification.json`. `actual-markers.csv` comes from the supplied exporter; the browser overlays its coordinates against the intended tile centers.

AI technical review identified and fixed an identifier type-coercion issue; the regression check rejects array-valued IDs. Independent qualified human code review is pending. Inspect coordinate conventions, validation, CSV formatting and error behavior before using this in an engine importer.

Known limits: this is a trusted local sample, not an upload service. The one-megabyte check runs after the file is read and does not bound read-time memory use. No engine import, gameplay, reachability, large-file intake or accessibility audit was performed.
