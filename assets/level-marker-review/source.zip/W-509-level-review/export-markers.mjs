import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

export function exportMarkers(level) {
  if (!level || typeof level !== 'object' || Array.isArray(level)) throw new Error('Expected a level object.');
  for (const field of ['tileSize','widthTiles','heightTiles']) {
    if (!Number.isInteger(level[field]) || level[field] < 1 || level[field] > 4096) throw new Error(`Invalid ${field}.`);
  }
  if (!Array.isArray(level.markers) || level.markers.length > 256) throw new Error('Expected at most 256 markers.');
  const ids = new Set();
  const lines = ['id,kind,x,y'];
  for (const marker of level.markers) {
    if (!marker || typeof marker !== 'object' || typeof marker.id !== 'string' || !/^[a-z][a-z0-9_-]{0,31}$/.test(marker.id)) throw new Error('Invalid marker id.');
    if (ids.has(marker.id)) throw new Error(`Duplicate marker id: ${marker.id}.`);
    ids.add(marker.id);
    if (!['spawn','objective','hazard'].includes(marker.kind)) throw new Error(`Unsupported kind for ${marker.id}.`);
    if (!Number.isInteger(marker.column) || marker.column < 0 || marker.column >= level.widthTiles || !Number.isInteger(marker.row) || marker.row < 0 || marker.row >= level.heightTiles) throw new Error(`Out-of-grid marker: ${marker.id}.`);
    const x = (marker.column + 0.5) * level.tileSize;
    const y = (marker.row + 0.5) * level.tileSize;
    lines.push([marker.id,marker.kind,x,y].join(','));
  }
  return lines.join('\n') + '\n';
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    if (process.argv.length !== 3) throw new Error('Usage: node export-markers.mjs sample-level.json');
    const text = await readFile(process.argv[2],'utf8');
    if (Buffer.byteLength(text,'utf8') > 1024*1024) throw new Error('Input exceeds the one-megabyte limit.');
    process.stdout.write(exportMarkers(JSON.parse(text)));
  } catch (error) {
    process.stderr.write(`Export rejected: ${error.message}\n`);
    process.exitCode = 1;
  }
}
