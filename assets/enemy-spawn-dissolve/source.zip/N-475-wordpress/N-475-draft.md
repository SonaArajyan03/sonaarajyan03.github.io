# A Three.js enemy dissolve with a clear activation boundary

AI assistance was used to prepare this article and its small local demo. The example uses a capsule as an enemy stand-in, not a shipped game character.

An enemy can look ready before the game has actually made it active. A spawn cue should give the player time to read the arrival, while the scene code decides when the enemy can move, collide or attack. Mixing those decisions into a particle's lifetime makes the transition harder to review.

This example uses a 1.2-second spawn. Cyan flecks appear first, a cell-noise dissolve reveals the mesh from 0.2 seconds, and a separate activation flag becomes true at 1.2 seconds. NixieFX supplies the particle cue. The Three.js host supplies the mesh shader and transition clock.

## Give the scene its own clock

The worked example has one exported particle effect and one Three.js mesh. The mesh is a capsule with an extended `MeshStandardMaterial`; the particle effect contains 24 procedural billboards. Both follow the scene's elapsed time, but only the host changes the enemy's visibility and activation state.

The three checkpoints make the intended behavior easy to inspect:

| Elapsed time | Dissolve threshold | Enemy state | Particle cue |
| --- | --- | --- | --- |
| 0.10 s | 0 | Hidden, inactive | Flecks visible |
| 0.60 s | 0.4 | Partly revealed, inactive | Flecks fading |
| 1.20 s | 1 | Fully visible, active | Finished and removed |

A threshold of 0.4 does not promise that exactly 40 percent of the visible surface is present. It is a cutoff against the demo's cell mask. Camera angle, cell distribution and geometry affect the visible result.

The activation flag is diagnostic data. A real game must connect that boundary to its own AI, collision and combat systems. None of those systems are present here, so the preview does not prove that a rigged enemy can safely enter combat.

## Keep the exported cue small

The NixieFX project uses the `three-world-3d` profile. Its single emitter is non-looping, with zero continuous emission and one burst of 24 particles. A box emission region surrounds the stand-in. Each fleck has a fixed 0.8-second lifetime, shrinks over that lifetime and fades toward zero alpha.

The particles use unlit additive rendering, camera-facing circles, depth testing and no depth writes. The export declares no textures, meshes, material graphs or sub-effects, so this example needs no resource providers.

For a [visual particle editor for three.js](https://nixiefx.com/threejs-runtime/), the useful boundary is the compiled particle bundle: load it, verify its Three.js support report, and let the host own the scene transition around it. This sample pins `nixie-fx` to 0.1.20 and Three.js to 0.185.0. It consumes the compiled manifest through `loadVfxExportBundle`, then takes the effect from `effectsById`.

The source validates with zero errors and zero warnings. The Three.js support report has no blockers or partial-support warnings. A separate informational note describes Pixi's depth semantics; this sample only checks the Three.js path.

## Cut the mesh in the host material

The reveal is a clamped ramp. Before 0.2 seconds, the mesh stays hidden. Between 0.2 and 1.2 seconds, the threshold rises to one. The host passes that value to its material uniform:

```js
const progress = Math.min(1, Math.max(0,
  (elapsed - 0.2) / (1.2 - 0.2)
));
enemy.visible = progress > 0;
revealUniform.value = progress;
const enemyActive = elapsed >= 1.2;
```

The material's `onBeforeCompile` extension adds a local-position varying, hashes a grid of small cells, and discards fragments whose mask value is above the threshold. That creates actual holes rather than lowering the whole mesh's opacity. A narrow band near the threshold receives a cyan tint.

The mesh remains opaque with depth writes enabled. The fragment cutout and the particle transparency are separate choices. In the update loop, the host advances `vfx.update(deltaSeconds)` once while the particle instance exists. When its one-shot finishes, the host removes it; activation still follows the 1.2-second scene boundary.

## Be specific about the material limits

The particle material does not automatically rewrite the enemy's material. This cutout shader is code in the host, not an exported NixieFX material graph. It targets the pinned Three.js version and its shader chunks. A renderer upgrade needs a fresh compile and visual check.

The cell pattern is deliberately coarse. There is no noise texture, continuous dissolving contour or bloom pass. The cyan frontier is a color tint, not proof of an emissive bloom pipeline. The sample also has no shadow-casting setup or matching custom depth material; a production shadow pass would need its own dissolve handling.

The mask uses the capsule's local positions. A rigged or morphing character needs a deliberate choice of mask coordinates and deformation behavior. Those cases were not tested. NixieFX's `clockSpace` option is currently reserved and unused, so it is not the synchronization mechanism. Collision, trails, lights and custom particle material graphs are disabled here.

## Check interrupted spawns too

Leaving the demo scene cancels its animation callback, removes the particle instance and hides the mesh. Attempts to step an inactive scene return before advancing simulation. Hiding the browser page pauses playback; the user restarts it explicitly.

The exported effect was loaded through the public runtime API and stepped at a fixed 60 Hz. That check observed a peak of 24 particles and no missing mesh or material references. It verifies the cue's lifecycle, not a frame-rate budget. Browser inspection confirmed the cutout at 0.6 seconds and the intact mesh at 1.2 seconds; all four transition and scene-exit checks passed.

The source project still needs review inside the real NixieFX editor. Production material, gameplay, reduced-motion and accessibility behavior also need review. Start with the halfway frame: the enemy should be recognizable while still inactive. Then replace the capsule and check the actual game scene, including interrupted spawns, shadow passes and neighboring transparent effects.
