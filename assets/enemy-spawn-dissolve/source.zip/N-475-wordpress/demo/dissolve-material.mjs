import {MeshStandardMaterial} from 'three';

// This shader extension belongs to the host, not to the particle export.
export function createDissolveMaterial(){
 const reveal={value:0};
 const material=new MeshStandardMaterial({color:0x81aabc,roughness:.8,metalness:0});
 material.onBeforeCompile=shader=>{
  shader.uniforms.uSpawnReveal=reveal;
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vSpawnLocal;')
   .replace('#include <begin_vertex>','#include <begin_vertex>\nvSpawnLocal = position;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>',`#include <common>
uniform float uSpawnReveal;
varying vec3 vSpawnLocal;
float spawnCellMask(vec3 p) {
  vec3 cell = floor(p * 10.0);
  return fract(sin(dot(cell, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
}`)
   .replace('#include <color_fragment>',`#include <color_fragment>
float spawnMask = spawnCellMask(vSpawnLocal);
if (spawnMask > uSpawnReveal) discard;
float spawnEdge = smoothstep(uSpawnReveal - 0.08, uSpawnReveal, spawnMask);
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.2, 0.9, 1.0), spawnEdge);`);
 };
 material.customProgramCacheKey=()=> 'sona-enemy-spawn-cell-cutout-v1';
 return {material,reveal};
}
