import * as THREE from 'three';
import {loadVfxExportBundle} from 'nixie-fx/export';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {transitionAt} from './transition.mjs';
import {createDissolveMaterial} from './dissolve-material.mjs';

async function main(){
const canvas=document.querySelector('#scene');const renderer=new THREE.WebGLRenderer({canvas,antialias:true});renderer.setSize(900,430,false);renderer.setPixelRatio(1);
const scene=new THREE.Scene();scene.background=new THREE.Color('#172a3b');
const camera=new THREE.PerspectiveCamera(38,900/430,.1,40);camera.position.set(4,3,6);camera.lookAt(0,.85,0);camera.updateMatrixWorld();
scene.add(new THREE.HemisphereLight(0xcfeeff,0x283320,2));const light=new THREE.DirectionalLight(0xffffff,2);light.position.set(3,5,2);scene.add(light);
const grid=new THREE.GridHelper(8,16,0x527789,0x2e4e60);scene.add(grid);
const ring=new THREE.Mesh(new THREE.TorusGeometry(.78,.035,8,64),new THREE.MeshBasicMaterial({color:0x76d6e8}));ring.rotation.x=Math.PI/2;ring.position.y=.03;scene.add(ring);
const geometry=new THREE.CapsuleGeometry(.38,.95,6,16);const {material,reveal}=createDissolveMaterial();
const enemy=new THREE.Mesh(geometry,material);enemy.position.y=.855;enemy.visible=false;scene.add(enemy);
const json=async path=>{const response=await fetch(path);if(!response.ok)throw new Error(`Bundle fetch ${response.status}: ${path}`);return response.json();};
const manifest=await json('./vfx/manifest.json');const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,await json(`./vfx/${e.path}`)])));
const bundle=loadVfxExportBundle({manifest,effectsByPath,assetPaths:[]},{requiredBackend:'three3d',requiredEffectIds:['enemy-spawn-flecks'],requireEveryAsset:true});
const definition=bundle.effectsById.get('enemy-spawn-flecks');const vfx=new ThreeVfxRenderer({scene,camera});
let fx=null,time=0,inScene=true,playing=false,updateCalls=0,last=0,frameId=0;const checks=[];const message=document.querySelector('#message');
function release(){if(fx){vfx.removeEffect(fx,true);fx=null;}}
function apply(){const state=transitionAt(time);enemy.visible=inScene&&state.visible;reveal.value=state.revealProgress;return state;}
function snapshot(){const s=vfx.stats;return{...apply(),inScene,playing,enemyVisible:enemy.visible,enemyDepthWrite:material.depthWrite,materialTransparent:material.transparent,hostDissolveUniform:reveal.value,effectCount:s.effectCount,activeParticles:s.activeParticles,capacity:s.capacity,missingMeshRefs:s.missingMeshRefs,missingMaterialRefs:s.missingMaterialRefs,unsupportedFeatures:s.unsupportedFeatures,updateCalls};}
function render(){renderer.render(scene,camera);document.querySelector('#stats').textContent=JSON.stringify({state:snapshot(),checks},null,2);}
function stop(){playing=false;cancelAnimationFrame(frameId);}
function reset(){stop();release();inScene=true;time=0;updateCalls=0;fx=vfx.createEffect(definition,{position:[0,0,0],seed:475});apply();}
function step(dt){if(!inScene)return;time+=dt;if(fx){vfx.update(dt);updateCalls++;if(!fx.isActive)release();}apply();}
function freeze(target){reset();const frames=Math.round(target*60);for(let i=0;i<frames;i++)step(1/60);render();message.textContent=`Paused at ${time.toFixed(2)} s. ${transitionAt(time).stage}.`;}
document.querySelector('#cue').onclick=()=>freeze(.1);document.querySelector('#mid').onclick=()=>freeze(.6);document.querySelector('#end').onclick=()=>freeze(1.2);
document.querySelector('#play').onclick=()=>{reset();playing=true;last=performance.now();message.textContent='Host owns the reveal clock; NixieFX advances once per frame while the cue exists.';const frame=now=>{if(!playing||!inScene)return;const dt=(now-last)/1000;last=now;step(dt);render();if(time>=1.5){stop();return;}frameId=requestAnimationFrame(frame);};frameId=requestAnimationFrame(frame);};
document.querySelector('#leave').onclick=()=>{stop();inScene=false;release();apply();render();message.textContent='Scene left: particle instance removed, frame callback stopped, enemy hidden.';};
document.querySelector('#verify').onclick=()=>{checks.length=0;for(const t of [.1,.6,1.2]){freeze(t);const s=snapshot();checks.push({check:`transition at ${t.toFixed(2)} s`,passed:t===.1?!s.enemyVisible&&!s.active:t===.6?s.enemyVisible&&s.revealProgress===.4&&!s.active:s.enemyVisible&&s.revealProgress===1&&s.active&&s.effectCount===0,...s});}freeze(.6);stop();inScene=false;release();apply();const before=updateCalls;for(let i=0;i<60;i++)step(1/60);const stopped=snapshot();checks.push({check:'60 attempted updates after leaving',passed:stopped.effectCount===0&&!stopped.enemyVisible&&updateCalls===before,simulationCallsAfterLeave:updateCalls-before,...stopped});freeze(.6);render();message.textContent='Lifecycle checks complete. Values are not a GPU benchmark or gameplay integration test.';};
document.addEventListener('visibilitychange',()=>{if(document.hidden){stop();message.textContent='Hidden page: playback paused. Press Play spawn to restart.';render();}});
window.addEventListener('pagehide',()=>{stop();release();vfx.destroy();geometry.dispose();material.dispose();ring.geometry.dispose();ring.material.dispose();grid.geometry.dispose();grid.material.dispose();renderer.dispose();});
freeze(.6);
}
main().catch(error=>{document.querySelector('#message').textContent=`Demo error: ${error.message}`;console.error(error);});
