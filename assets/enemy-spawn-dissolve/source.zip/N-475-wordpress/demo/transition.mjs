export const REVEAL_START=.2,REVEAL_END=1.2;
export function transitionAt(time){
 const t=Math.max(0,time);const progress=Math.min(1,Math.max(0,(t-REVEAL_START)/(REVEAL_END-REVEAL_START)));
 return {time:+t.toFixed(3),visible:progress>0,revealProgress:+progress.toFixed(4),active:t>=REVEAL_END,stage:t<REVEAL_START?'spawn cue':t<REVEAL_END?'revealing':'active'};
}
