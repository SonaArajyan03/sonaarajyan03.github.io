# N-475: enemy spawn timed reveal

This local prototype combines a canonical NixieFX Three.js export with a host-owned Three.js cell-noise surface dissolve. The particle export does not modify the mesh material.

From `demo`, use Node 20+:

```sh
npm ci
npm run vfx:validate
npm run vfx:export
npm run vfx:status
npm run dev
```

For a relocatable static preview, run `npm run build`; serve `dist` over HTTP. The compiled effect lives under `public/vfx`, and the host reads that bundle via the public loader. Do not substitute the source JSON as a game input.

At 0.10 s the mesh is hidden; at 0.60 s its cutout threshold is 0.4; at 1.20 s it is opaque and marked active. The activation flag is a demonstration of a boundary, not combat code. Leaving the scene destroys the effect instance, hides the stand-in and stops its animation callback.

The emitter is a 24-particle non-looping burst. Unlit additive procedural circles fade and shrink for 0.8 s, with depth test on, depth writes off. There are no external assets or custom material graphs.

Limitations: no rigged enemy, production character material, bloom pass, device performance benchmark or production collision/AI system. Transparent object sorting, reduced-motion behavior and accessibility need review in the real game. NixieFX editor visual review remains pending. The standalone build currently reports a chunk-size warning.

Official references checked: https://nixiefx.com/threejs-runtime/ and https://threejs.org/docs/#api/en/materials/Material . The article contains only its assigned contextual product link.
