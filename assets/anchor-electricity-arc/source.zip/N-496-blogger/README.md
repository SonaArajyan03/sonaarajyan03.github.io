# N-496: electricity arc with a moving endpoint

The arc is one NixieFX Three.js mesh particle referencing an exported prepared jagged mesh asset. The host computes a transform from its two anchors; it draws no separate arc line or shader.

From `demo`, with Node 20+:

```sh
npm ci
npm run vfx:validate
npm run vfx:export
npm run vfx:status
npm run dev
```

`npm run build` produces relocatable `dist` files. Serve them over HTTP; the bundle fetches and asset paths are relative to the demo's directory. `configure-effect.mjs` edits the canonical CLI-generated source and prepares the mesh asset before exporting. Generated compiled bundle files must not be patched by hand.

The host decodes the declared mesh JSON into Three.js BufferGeometry, then exposes it through the public mesh provider. The compiled bundle loader verifies Three.js support, required effect identity and complete asset coverage. A fixed seed of 496 is used.

Anchor A is fixed, B moves in three dimensions. The prepared arc's center endpoints are (0,0,0) and (1,0,0), allowing the public `setTransform` API to fit the geometry. Each host frame advances `vfx.update` exactly once while the arc is powered. Power-off, coincident anchors and the 10-second limit remove its instance. Hidden pages pause playback; explicit Play restarts the sample.

Limits: fixed prepared shape, no branch generator, collision solver, real ribbon, bloom, light emission or device performance measurement. Scaling the span changes kink geometry. PixiJS cannot render this prepared 3D mesh-particle effect; its manifest backend is blocked. The real NixieFX editor visual review, production socket integration and reduced-motion/accessibility handling remain pending.

Official runtime reference checked: https://nixiefx.com/threejs-runtime/ . Source package types and renderer behavior were audited for the pinned 0.1.20 public release; integration imports only public entrypoints.
