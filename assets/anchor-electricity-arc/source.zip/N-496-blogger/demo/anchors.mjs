import {Euler,Quaternion,Vector3} from 'three';
const localAxis=new Vector3(1,0,0);
export function anchorsAt(t){return{a:new Vector3(-2,.85,0),b:new Vector3(2+.4*Math.sin(.7*t),1.5+.75*Math.sin(1.2*t),.8*Math.cos(.8*t))};}
export function fitArc(a,b){const delta=new Vector3().subVectors(b,a);const length=delta.length();if(length<.01)return null;const quaternion=new Quaternion().setFromUnitVectors(localAxis,delta.clone().normalize());return{position:a.toArray(),rotation:new Euler().setFromQuaternion(quaternion).toArray().slice(0,3),scale:[length,1,1],length};}
