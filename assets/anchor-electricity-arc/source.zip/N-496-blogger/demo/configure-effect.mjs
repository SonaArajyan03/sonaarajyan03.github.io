import {readFile,writeFile} from 'node:fs/promises';
import {BufferGeometry,CurvePath,LineCurve3,TubeGeometry,Vector3} from 'three';

// Prepared geometry, exported as an ordinary mesh asset. No host line is drawn.
const centers=[[0,0,0],[.09,.07,.02],[.17,-.05,-.02],[.25,.09,.015],[.33,-.08,0],[.42,.065,-.02],[.50,-.09,.02],[.59,.085,0],[.67,-.05,-.02],[.75,.07,.015],[.84,-.06,0],[.92,.05,.02],[1,0,0]];
const path=new CurvePath();for(let i=1;i<centers.length;i++)path.add(new LineCurve3(new Vector3(...centers[i-1]),new Vector3(...centers[i])));
const tube=new TubeGeometry(path,120,.012,5,false);const geometry=new BufferGeometry().copy(tube);geometry.computeBoundingBox();
await writeFile(new URL('./assets/meshes/electric-arc.json',import.meta.url),JSON.stringify(geometry.toJSON())+'\n');
await writeFile(new URL('./arc-centers.json',import.meta.url),JSON.stringify(centers)+'\n');tube.dispose();geometry.dispose();
const file=new URL('./effects/anchor-electricity-arc.json',import.meta.url);const effect=JSON.parse(await readFile(file,'utf8'));const e=effect.emitters[0];
const constant=(base,value)=>({...base,mode:'constant',value,min:value,max:value,curve:[{x:0,y:value},{x:1,y:value}],curveB:[{x:0,y:value},{x:1,y:value}]});
e.id='electric-arc-mesh-496';e.name='Prepared arc mesh';e.mode='mesh';e.loop=false;e.duration=10;e.maxParticles=1;
e.spawn.shape='point';e.spawn.position=[0,0,0];e.spawn.simulationSpace='local';e.spawn.rate=0;e.spawn.rateValue=constant(e.spawn.rateValue,0);e.spawn.bursts=[{time:0,count:1,cycles:1,interval:0,probability:1}];
e.initializeParticle.lifetime=constant(e.initializeParticle.lifetime,10);e.initializeParticle.size=constant(e.initializeParticle.size,1);e.initializeParticle.velocity.min=e.initializeParticle.velocity.max=[0,0,0];
e.modules.velocity=false;e.modules.color=true;e.modules.size=false;
e.render.shading='unlit';e.render.blend='additive';e.render.depthTest=true;e.render.depthWrite=false;e.render.depthInk=false;
e.render.alignAxis='vector';e.render.alignment='vector';e.render.alignmentVector=[0,0,1];e.render.facing='off';
e.mesh.renderMode='meshAsset';e.mesh.asset={type:'mesh',id:'electric-arc-mesh-496',path:'meshes/electric-arc.json'};e.mesh.sizeStart=e.mesh.sizeEnd=1;e.mesh.sizeValue=constant(e.mesh.sizeValue,1);e.mesh.separateAxes=false;e.mesh.pivot=[0,0,0];
e.color.gradient={mode:'blend',colorStops:[{position:0,color:[.3,.85,1]},{position:1,color:[.3,.85,1]}],alphaStops:[{position:0,alpha:1},{position:1,alpha:1}]};effect.timeline.duration=10;
await writeFile(file,JSON.stringify(effect,null,2)+'\n');console.log('Prepared one true mesh particle with exported jagged arc geometry.');
