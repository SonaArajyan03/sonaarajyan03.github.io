import * as THREE from 'three';
import {loadVfxExportBundle} from 'nixie-fx/export';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {anchorsAt,fitArc} from './anchors.mjs';

async function main(){
const canvas=document.querySelector('#scene');const renderer=new THREE.WebGLRenderer({canvas,antialias:true});renderer.setSize(920,440,false);renderer.setPixelRatio(1);
const scene=new THREE.Scene();scene.background=new THREE.Color('#15293a');const camera=new THREE.PerspectiveCamera(40,920/440,.1,50);camera.position.set(4,3,7);camera.lookAt(0,1.2,0);camera.updateMatrixWorld();
const grid=new THREE.GridHelper(10,20,0x577587,0x294a5b);scene.add(grid);
const anchorGeometry=new THREE.SphereGeometry(.1,12,8);const anchorMaterialA=new THREE.MeshBasicMaterial({color:0xfcc87a}),anchorMaterialB=new THREE.MeshBasicMaterial({color:0x8be8d6});const anchorA=new THREE.Mesh(anchorGeometry,anchorMaterialA),anchorB=new THREE.Mesh(anchorGeometry,anchorMaterialB);scene.add(anchorA,anchorB);
const json=async path=>{const r=await fetch(path);if(!r.ok)throw new Error(`Export fetch ${r.status}: ${path}`);return r.json();};
const manifest=await json('./vfx/manifest.json');const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,await json(`./vfx/${e.path}`)])));
const geometries=new Map();const loader=new THREE.BufferGeometryLoader();for(const asset of manifest.assets){if(asset.type!=='mesh')throw new Error('Unexpected non-mesh asset');geometries.set(asset.path,loader.parse(await json(`./vfx/${asset.path}`)));}
const bundle=loadVfxExportBundle({manifest,effectsByPath,assetPaths:[...geometries.keys()]},{requiredBackend:'three3d',requiredEffectIds:['anchor-electricity-arc'],requireEveryAsset:true});const definition=bundle.effectsById.get('anchor-electricity-arc');
const vfx=new ThreeVfxRenderer({scene,camera,meshProvider:{getMeshGeometry:ref=>geometries.get(ref.path)??null}});
let fx=null,t=0,powered=true,playing=false,coincident=false,updateCalls=0,last=0,frameId=0;const checks=[];const message=document.querySelector('#message');
let currentA=new THREE.Vector3(),currentB=new THREE.Vector3(),endpointErrors=null;
function release(){if(fx){vfx.removeEffect(fx,true);fx=null;}}
function stop(){playing=false;cancelAnimationFrame(frameId);}
function locate(){const p=anchorsAt(t);currentA=p.a;currentB=coincident?p.a.clone():p.b;anchorA.position.copy(currentA);anchorB.position.copy(currentB);return fitArc(currentA,currentB);}
function reconcile(){const fit=locate();if(!powered||!fit||t>=10){release();return null;}if(!fx)fx=vfx.createEffect(definition,{seed:496});fx.setTransform(fit);fx.setEmitterRuntimeParameters('electric-arc-mesh-496',{colorTint:[1,1,1,.6+.3*Math.sin(t*37)]});return fit;}
function endpointCheck(){endpointErrors=null;if(!fx)return;scene.updateMatrixWorld(true);const debug=fx.getParticleDebugTransforms()[0];if(!debug)return;const matrix=new THREE.Matrix4().multiplyMatrices(fx.root.matrixWorld,new THREE.Matrix4().fromArray(debug.matrix));const start=new THREE.Vector3(0,0,0).applyMatrix4(matrix),end=new THREE.Vector3(1,0,0).applyMatrix4(matrix);endpointErrors={start:start.distanceTo(currentA),end:end.distanceTo(currentB),renderedStart:start.toArray(),renderedEnd:end.toArray(),mode:debug.mode};}
function state(){const s=vfx.stats;return{time:+t.toFixed(3),anchorA:currentA.toArray(),anchorB:currentB.toArray(),distance:currentA.distanceTo(currentB),powered,playing,coincident,endpointErrors,effectCount:s.effectCount,activeParticles:s.activeParticles,capacity:s.capacity,missingMeshRefs:s.missingMeshRefs,missingMaterialRefs:s.missingMaterialRefs,unsupportedFeatures:s.unsupportedFeatures,updateCalls};}
function render(){endpointCheck();renderer.render(scene,camera);document.querySelector('#stats').textContent=JSON.stringify({state:state(),checks},null,2);}
function step(dt){if(!powered||coincident||t>=10)return;t+=dt;const fit=reconcile();if(fit&&fx){vfx.update(dt);updateCalls++;}if(t>=10){powered=false;release();stop();}endpointCheck();}
function reset(){stop();release();t=0;powered=true;coincident=false;updateCalls=0;reconcile();}
function freeze(time){reset();for(let i=0;i<Math.round(time*60);i++)step(1/60);render();message.textContent=`Paused at ${t.toFixed(2)} s; endpoint center residual is measured from the rendered particle matrix.`;}
document.querySelector('#one').onclick=()=>freeze(1);document.querySelector('#three').onclick=()=>freeze(3);
document.querySelector('#play').onclick=()=>{reset();playing=true;last=performance.now();const frame=now=>{if(!playing)return;step((now-last)/1000);last=now;render();if(playing)frameId=requestAnimationFrame(frame);};frameId=requestAnimationFrame(frame);message.textContent='Moving B, fitting the exported arc, updating NixieFX once per host frame.';};
document.querySelector('#stop').onclick=()=>{stop();powered=false;release();render();message.textContent='Power off: no effect instance and no simulation updates.';};
document.querySelector('#coincident').onclick=()=>{stop();coincident=true;reconcile();render();message.textContent='Coincident anchors: zero-length arc removed before normalization.';};
document.querySelector('#verify').onclick=()=>{checks.length=0;const positions=[];for(const target of [1,3]){freeze(target);const s=state();positions.push(s.anchorB);checks.push({check:`endpoint attachment at ${target}s`,passed:s.effectCount===1&&s.activeParticles===1&&s.endpointErrors?.mode==='meshAsset'&&s.endpointErrors.start<1e-6&&s.endpointErrors.end<1e-6,...s});}checks.push({check:'B actually moved',passed:new THREE.Vector3(...positions[0]).distanceTo(new THREE.Vector3(...positions[1]))>.1,positions});stop();powered=false;release();const before=updateCalls;for(let i=0;i<60;i++)step(1/60);checks.push({check:'60 attempted updates after power off',passed:updateCalls===before&&vfx.stats.effectCount===0&&vfx.stats.capacity===0,simulationCallsAfterStop:updateCalls-before,...state()});reset();coincident=true;reconcile();checks.push({check:'coincident anchor guard',passed:vfx.stats.effectCount===0&&vfx.stats.capacity===0,...state()});freeze(3);render();message.textContent='Checks complete. Endpoint attachment is tested; no performance benchmark is claimed.';};
document.addEventListener('visibilitychange',()=>{if(document.hidden){stop();message.textContent='Hidden page: paused. Play restarts explicitly.';render();}});
window.addEventListener('pagehide',()=>{stop();release();vfx.destroy();for(const g of geometries.values())g.dispose();anchorGeometry.dispose();anchorMaterialA.dispose();anchorMaterialB.dispose();grid.geometry.dispose();grid.material.dispose();renderer.dispose();});
freeze(1);
}
main().catch(error=>{document.querySelector('#message').textContent=`Demo error: ${error.message}`;console.error(error);});
