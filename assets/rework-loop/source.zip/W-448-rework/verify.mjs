import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {firstAttempt,correctedAttempt} from './export-attempts.mjs';

const root=dirname(fileURLToPath(import.meta.url));
const input=readFileSync(resolve(root,'source.json'),'utf8');
const source=JSON.parse(input);
// Expected acceptance data is explicit and separate from the export implementation.
const expected=[
  {id:'REL-010',label:'Check landscape layout'},
  {id:'REL-030',label:'Review reward copy'},
  {id:'REL-040',label:'Verify reconnect message'},
];
const hash=text=>createHash('sha256').update(text).digest('hex');
const verify=delivery=>{
  const actualIds=delivery.items.map(x=>x.id);
  const expectedIds=expected.map(x=>x.id);
  const reasons=[];
  if(delivery.taskId!=='DEMO-214')reasons.push('Task identity changed.');
  if(actualIds.includes('REL-020'))reasons.push('Archived REL-020 is included; archived records are outside the requested export.');
  const presentExpected=actualIds.filter(x=>expectedIds.includes(x));
  if(JSON.stringify(presentExpected)!==JSON.stringify(expectedIds))reasons.push('Active identifiers are not in the required REL-010, REL-030, REL-040 order.');
  if(JSON.stringify(delivery.items)!==JSON.stringify(expected))reasons.push('Export does not exactly match the independent expected records.');
  return {pass:reasons.length===0,reasons,actualIds,expectedIds};
};
const before=JSON.stringify(source);
const first=firstAttempt(source),corrected=correctedAttempt(source);
if(JSON.stringify(source)!==before)throw new Error('Source fixture was mutated.');
const checks=[{attempt:1,...verify(first)},{attempt:2,...verify(corrected)}];
if(checks[0].pass || !checks[1].pass)throw new Error('Illustrative rejection/correction did not produce expected check results.');
const attemptFiles=['attempt-1.json','attempt-2.json'];
const artifacts=[first,corrected].map((delivery,i)=>{
  const text=JSON.stringify(delivery,null,2)+'\n';
  writeFileSync(resolve(root,attemptFiles[i]),text);
  return {attempt:i+1,file:attemptFiles[i],sha256:hash(text),standingCandidate:i===1};
});
const report={synthetic:true,scope:'Local illustrative fixture; not Wagglet state or a human review',taskId:'DEMO-214',runnerId:source.runnerId,sourceSha256:hash(input),implementationSha256:hash(readFileSync(resolve(root,'export-attempts.mjs'),'utf8')),sourceUnchanged:JSON.stringify(source)===before,checks,artifacts,acceptance:'Pending human review; passing checks do not mark a task Done',merge:'Not performed',deployment:'Not performed'};
writeFileSync(resolve(root,'verification.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
