// Local illustrative exports. No Wagglet API calls and no external dependencies.
export function firstAttempt(source) {
  return { taskId: source.taskId, attempt: 1,
    items: source.items.map(({id,label}) => ({id,label})) };
}

export function correctedAttempt(source) {
  return { taskId: source.taskId, attempt: 2,
    items: source.items.filter(item => item.archived === false)
      .map(({id,label}) => ({id,label}))
      .sort((a,b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0) };
}
