W-448 original illustrative rework fixture

This is local example evidence. It does not integrate with Wagglet, exercise any
Wagglet API, change a real ticket, claim a human review, or merge/deploy code.

Run with Node.js 20 or newer:
  node verify.mjs

No dependencies, package install, credentials, network, or database needed.
The script writes only these files in its own directory:
  attempt-1.json, attempt-2.json, verification.json

source.json contains synthetic release-checklist records and task DEMO-214.
export-attempts.mjs contains the intentionally failing and corrected exporters.
verify.mjs compares their outputs to separately written expected records and
checks that the input object was not mutated. It fails if attempt 1 unexpectedly
passes or attempt 2 fails. Output and source hashes are recorded in verification.json.
review-rework.json is an illustrative timeline, not an API export.

Observed run: attempt 1 fails the requested scope, attempt 2 passes, input unchanged.
The first delivery includes archived REL-020 and returns active items out of order.
The second returns REL-010, REL-030, REL-040 with the correct labels and same task ID.

Limits: one fixed fixture, not a general export library. No malformed input,
database, access-control, dataset-size, production build, or mobile checks were run.
No human acceptance has occurred. The review/rework timeline is a proposed example.
