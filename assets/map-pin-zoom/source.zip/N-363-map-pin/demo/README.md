# Objective pulse independent of map zoom

Node.js 20 or newer. Pinned PixiJS 8.22.0, nixie-fx 0.1.20 and Vite 6.4.4.

```sh
npm ci
npm run vfx:validate
npm run vfx:export
npm run dev
```

Open `http://127.0.0.1:5201/`. Inspect at 2.00 seconds, switch between zoom 0.55 and 0.85, and run Verify lifecycle. The map world scales; the pin belongs to an unscaled sibling overlay. Its `(600,300)` world point converts into `(330,165)` and `(510,255)` viewport-local positions. Pin scale stays `(1,1)`.

The single looping emitter has rate 2/s, lifetime 1.2s and capacity 4. Its compiled bundle is included at `public/vfx`. Game code loads this export via the public bundle loader, not the authoring JSON. `configure-effect.mjs` edits the canonical CLI-generated authoring source; export after changing it.

The actual runtime check ran 600 fixed updates with one instance and peak three particles. Untracking, completion, an off-screen center, map closure and VFX disablement remove the effect. Every removal produced zero instances, active particles and capacity; 60 attempted updates afterwards produced zero VFX simulation calls. Reopening a completed objective did not recreate it, and repeated active reconciliation did not duplicate instances.

Normal playback calls `renderer.update` once per host frame. Hidden tabs pause playback, closed/ineligible maps stop the ticker, and page teardown destroys the renderer and Pixi application. Destroying the instance differs from pausing emission; the static objective marker remains.

`npm run build` uses relative asset paths for hosting the generated static demo beneath a GitHub Pages subdirectory. It passes with a Vite bundle-size warning. The frame-count check is not a GPU, CPU timing, frame-rate or phone benchmark.

No unsupported settings are enabled. Lit shading requires Three; Pixi depth-write uses draw ordering rather than GPU depth-buffer writing, and is disabled. Trails, sub-emitters, custom materials, lights and file textures are unused. Real-editor visual review, automatic OS reduced-motion handling and a full accessibility audit are pending. The on-screen check uses the pin center and may clip the glow near viewport edges.
