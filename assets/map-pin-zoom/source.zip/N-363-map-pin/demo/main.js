import {Application,Container,Graphics,Point,Text} from 'pixi.js';
import {loadVfxExportBundle} from 'nixie-fx/export';
import {PixiVfxRenderer,createPixiVfx2dProjection} from 'nixie-fx/pixi';

async function main(){
const app=new Application();await app.init({width:900,height:460,resolution:1,background:'#172838',antialias:true,autoDensity:true});document.querySelector('#scene').appendChild(app.canvas);app.stop();
const json=async path=>{const r=await fetch(path);if(!r.ok)throw new Error(`Failed export fetch: ${r.status}`);return r.json();};
const manifest=await json('./vfx/manifest.json');const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,await json(`./vfx/${e.path}`)])));
const bundle=loadVfxExportBundle({manifest,effectsByPath,assetPaths:manifest.assets.map(a=>a.path)},{requiredBackend:'pixi2d',requiredEffectIds:['map-pin-zoom-pulse'],requireEveryAsset:true});const definition=bundle.effectsById.get('map-pin-zoom-pulse');
const text=(value,x,y,size=16,color='#dfeaf5',parent=app.stage)=>{const t=new Text({text:value,style:{fontFamily:'Arial',fontSize:size,fill:color}});t.position.set(x,y);parent.addChild(t);return t;};
text('LOCAL MAP · ONE TRACKED OBJECTIVE',24,20,13,'#a8c7da');text('A screen-space cue anchored to a world-space point',24,43,21);
const viewport=new Container();viewport.position.set(24,82);app.stage.addChild(viewport);viewport.addChild(new Graphics().rect(0,0,640,350).fill('#1b3644'));
const clip=new Graphics().rect(24,82,640,350).fill('#ffffff');app.stage.addChild(clip);viewport.mask=clip;
const world=new Container();viewport.addChild(world);
const map=new Graphics().rect(0,0,1100,600).fill('#264550');for(let x=0;x<=1100;x+=100)map.moveTo(x,0).lineTo(x,600);for(let y=0;y<=600;y+=100)map.moveTo(0,y).lineTo(1100,y);map.stroke({color:'#4d7077',width:2});
map.roundRect(75,70,360,150,24).fill('#375c56');map.roundRect(690,340,270,160,24).fill('#3b596b');map.moveTo(0,310).bezierCurveTo(360,420,570,140,1100,270).stroke({color:'#6c91a4',width:22});world.addChild(map);
const worldPoint=new Point(600,300);world.addChild(new Graphics().circle(worldPoint.x,worldPoint.y,4).fill('#ffffff'));
const overlay=new Container();viewport.addChild(overlay);const pin=new Container();overlay.addChild(pin);
const pulse=new Container();pin.addChild(pulse);const marker=new Graphics();pin.addChild(marker);const label=text('EAST GATE',12,-7,13,'#ffe0a8',pin);
const info=text('',691,110,15);const detail=text('',691,177,14,'#b7ceda');
const renderer=new PixiVfxRenderer({parent:pulse,projection:createPixiVfx2dProjection({originX:0,originY:0,pixelsPerUnit:40,yAxis:'up'})});
let fx=null,zoom=.55,panX=0,mapOpen=true,tracked=true,completed=false,enabled=true,autoPlay=false,elapsed=0,updateCalls=0;const checks=[];
const message=document.querySelector('#message');
function onScreen(){return pin.x>=0&&pin.x<=640&&pin.y>=0&&pin.y<=350;}
function shouldRun(){return mapOpen&&tracked&&!completed&&enabled&&onScreen();}
function release(){if(fx){renderer.removeEffect(fx,true);fx=null;}}
function state(){const s=renderer.stats;return{zoom,worldPoint:[600,300],pinLocal:[+pin.x.toFixed(2),+pin.y.toFixed(2)],pinScale:[pin.scale.x,pin.scale.y],mapOpen,tracked,completed,enabled,onScreen:onScreen(),running:shouldRun(),elapsed:+elapsed.toFixed(3),updateCalls,effectCount:s.effectCount,activeParticles:s.activeParticles,capacity:s.capacity,missingTextureRefs:s.missingTextureRefs,missingMaterialRefs:s.missingMaterialRefs,missingSubEmitterRefs:s.missingSubEmitterRefs,unsupportedModules:s.unsupportedModules,unsupportedFeatures:s.unsupportedFeatures,tickerStarted:app.ticker.started};}
function report(){document.querySelector('#stats').textContent=JSON.stringify({state:state(),checks},null,2);}
function reconcile(play=autoPlay){
 world.scale.set(zoom);world.position.set(panX,0);
 const global=world.toGlobal(worldPoint);viewport.toLocal(global,undefined,pin.position);
 viewport.visible=mapOpen;pin.visible=onScreen();
 marker.clear().circle(0,0,8).fill(completed?'#92ddac':'#f3c16b').stroke({color:'#fdf3d3',width:2});marker.poly([-3,-1,0,3,5,-4]).stroke({color:completed?'#16432a':'#71521e',width:1.5});
 label.text=completed?'GATE · COMPLETE':'EAST GATE';info.text=`ZOOM ${zoom.toFixed(2)}\nWORLD 600, 300\nPIN ${pin.x.toFixed(0)}, ${pin.y.toFixed(0)}`;detail.text=completed?'Objective complete\nStatic marker remains':tracked?'Objective tracked\nPin scale 1 × 1':'Objective untracked\nStatic marker remains';
 if(shouldRun()){if(!fx){fx=renderer.createEffect(definition,{seed:363});elapsed=0;}}else release();
 pulse.visible=shouldRun();if(play&&shouldRun()&&!document.hidden)app.start();else app.stop();app.render();report();
}
function step(dt){if(shouldRun()&&fx){renderer.update(dt);elapsed+=dt;updateCalls++;}}
app.ticker.add(ticker=>{step(ticker.deltaMS/1000);report();});
function action(fn,note){fn();reconcile();message.textContent=note;}
document.querySelector('#zoom-out').onclick=()=>action(()=>zoom=.55,'Map scale changed; the overlay pin scale stays at 1 × 1.');
document.querySelector('#zoom-in').onclick=()=>action(()=>zoom=.85,'Map scale changed; the overlay pin scale stays at 1 × 1.');
document.querySelector('#pan-away').onclick=()=>action(()=>panX=-1000,'Off-screen objective: the effect instance was removed.');
document.querySelector('#restore').onclick=()=>action(()=>{panX=0;zoom=.55;},'Camera restored; eligibility is evaluated from objective state.');
document.querySelector('#track').onclick=()=>action(()=>{tracked=!tracked;document.querySelector('#track').textContent=tracked?'Untrack objective':'Track objective';},'Tracking changed; inactive effects are removed.');
document.querySelector('#complete').onclick=()=>action(()=>completed=true,'Objective complete: pulse removed; static marker remains.');
document.querySelector('#new').onclick=()=>action(()=>{release();completed=false;tracked=true;document.querySelector('#track').textContent='Untrack objective';},'New local demo objective; this is the only control that clears completion.');
document.querySelector('#motion').onclick=()=>action(()=>{enabled=!enabled;document.querySelector('#motion').textContent=enabled?'VFX off':'VFX on';},'Local VFX preference changed; the static objective is preserved.');
document.querySelector('#close').onclick=()=>action(()=>{mapOpen=!mapOpen;document.querySelector('#close').textContent=mapOpen?'Close map':'Open map';},'Map visibility changed; closed maps remove their effect instance.');
document.querySelector('#play').onclick=()=>{autoPlay=true;reconcile(true);message.textContent='Normal ticker playback. The renderer advances once per host frame.';};
document.querySelector('#freeze').onclick=()=>{autoPlay=false;app.stop();reconcile(false);if(fx){fx.reset({seed:363});elapsed=0;for(let i=0;i<120;i++)step(1/60);}app.render();report();message.textContent='Paused at 2.00 seconds with a fixed simulation clock.';};
document.querySelector('#verify').onclick=async()=>{
 const button=document.querySelector('#verify');button.disabled=true;autoPlay=false;app.stop();checks.length=0;release();zoom=.55;panX=0;mapOpen=tracked=enabled=true;completed=false;updateCalls=0;reconcile(false);fx.reset({seed:363});elapsed=0;
 let peakParticles=0;for(let i=0;i<600;i++){step(1/60);peakParticles=Math.max(peakParticles,renderer.stats.activeParticles);if(i%60===59)await new Promise(resolve=>requestAnimationFrame(resolve));}
 checks.push({check:'600 fixed updates of one loop',frames:600,peakParticles,...state()});
 const recordStop=(name,change)=>{change();reconcile(false);const before=updateCalls;for(let i=0;i<60;i++)step(1/60);const s=state();checks.push({check:name,manualFrames:60,simulationCallsAfterStop:updateCalls-before,passed:updateCalls===before&&s.effectCount===0&&s.activeParticles===0&&s.capacity===0,...s});};
 recordStop('untracked',()=>tracked=false);tracked=true;reconcile(false);
 recordStop('completed',()=>completed=true);mapOpen=false;reconcile(false);mapOpen=true;reconcile(false);checks.push({check:'reopening a completed objective does not recreate the pulse',passed:renderer.stats.effectCount===0,...state()});
 completed=false;reconcile(false);recordStop('off-screen',()=>panX=-1000);panX=0;reconcile(false);for(let i=0;i<5;i++)reconcile(false);checks.push({check:'repeated active reconciliation keeps one instance',passed:renderer.stats.effectCount===1,...state()});
 recordStop('map closed',()=>mapOpen=false);mapOpen=true;reconcile(false);recordStop('VFX disabled',()=>enabled=false);
 enabled=true;reconcile(false);fx.reset({seed:363});elapsed=0;for(let i=0;i<120;i++)step(1/60);app.render();report();button.disabled=false;message.textContent='Lifecycle checks complete. Counters are not a GPU or phone-performance benchmark.';
};
document.addEventListener('visibilitychange',()=>{if(document.hidden)app.stop();else if(autoPlay)reconcile(true);});
window.addEventListener('pagehide',()=>{app.stop();renderer.destroy();app.destroy(true,{children:true});});
reconcile(false);message.textContent='Ready. Inspect two zoom levels or run the lifecycle check.';
}
main().catch(error=>{document.querySelector('#message').textContent=`Demo error: ${error.message}`;console.error(error);});
