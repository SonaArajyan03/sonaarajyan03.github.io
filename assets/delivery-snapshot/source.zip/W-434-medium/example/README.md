# Delivery evidence from the same source snapshot

This is a local toy example. It is not a production repository or a real customer incident.

Requires Node.js 20 or newer. There are no npm dependencies.

```sh
node run-cases.mjs before
node run-cases.mjs candidate
node collect-evidence.mjs
python3 -m http.server 5200 --bind 127.0.0.1
```

The baseline command deliberately exits 1: four cases pass and three whitespace cases fail. The candidate exits 0: all seven cases pass. `collect-evidence.mjs` records both actual outputs and rejects a deliberately mismatched pairing of the passing candidate report with the baseline source.

Open `http://127.0.0.1:5200/before/index.html` and `http://127.0.0.1:5200/candidate/index.html`. Enter three spaces. The baseline enables Save; the candidate disables it. Enter `Harbor` in the candidate to enable Save again. Save does not persist anything.

`evidence/packet.json` includes the changed file, source hashes, actual browser checks, image hashes, capture methods and known limits. The PNGs came from the real browser input handlers. `record-captures.mjs` adds their hashes after capture.

`build-fixture.mjs` regenerates the initial fixture. It overwrites the two example snapshots, so do not run it after making changes you want to retain.

The seven tests cover the pure validation function. They do not test server-side validation, persistence, length rules, zero-width characters, keyboard accessibility, mobile browsers, Firefox or Safari. File hashes detect accidental mismatches; they do not authenticate the runner or replace qualified review.
