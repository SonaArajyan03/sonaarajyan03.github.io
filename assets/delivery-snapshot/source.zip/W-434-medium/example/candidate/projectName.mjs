export function canSaveProjectName(raw) {
  return raw.trim().length > 0;
}
