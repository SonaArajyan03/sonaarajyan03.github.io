import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const hash=async path=>createHash('sha256').update(await readFile(path)).digest('hex');
const packet=JSON.parse(await readFile('evidence/packet.json','utf8'));
packet.browserChecks={browser:'Chrome',interaction:'Filled the real Project name input with three ASCII spaces through browser automation; then filled Harbor in the candidate.',baselineWhitespaceSaveEnabled:true,candidateWhitespaceSaveEnabled:false,candidateHarborSaveEnabled:true};
packet.screenshots=[];
for(const snapshot of ['before','candidate']){
 const image=snapshot==='before'?'baseline-whitespace.png':'candidate-whitespace.png';
 packet.screenshots.push({image,source:`${snapshot}/projectName.mjs`,sourceSha256:await hash(`${snapshot}/projectName.mjs`),imageSha256:await hash(`evidence/${image}`),input:'three U+0020 ASCII spaces',captureMethod:'Actual Chrome viewport after the input event; no forced visual state.'});
}
await writeFile('evidence/packet.json',JSON.stringify(packet,null,2)+'\n');
console.log('Bound actual browser captures to their source snapshots.');
