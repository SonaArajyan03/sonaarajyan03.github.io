import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
const hash = async path => createHash('sha256').update(await readFile(path)).digest('hex');
await mkdir('evidence', { recursive: true });
const reports = {};
for (const snapshot of ['before', 'candidate']) {
  const run = spawnSync(process.execPath, ['run-cases.mjs', snapshot], { encoding: 'utf8' });
  if (!run.stdout || run.error) throw run.error ?? new Error(run.stderr);
  const report = JSON.parse(run.stdout);
  report.exitCode = run.status;
  reports[snapshot] = report;
  await writeFile(`evidence/${snapshot}-tests.json`, JSON.stringify(report, null, 2) + '\n');
}
if (reports.before.failed !== 3 || reports.candidate.failed !== 0) throw new Error('Unexpected regression result.');
const changedFiles = [];
for (const file of ['projectName.mjs', 'index.html', 'cases.json']) {
  const before = await hash(`before/${file}`), candidate = await hash(`candidate/${file}`);
  if (before !== candidate) changedFiles.push({ file, beforeSha256: before, candidateSha256: candidate });
}
const packet = {
  candidate: reports.candidate.sha256,
  testReportMatchesCandidate: reports.candidate.sha256 === await hash('candidate/projectName.mjs'),
  deliberateMismatch: { report: 'candidate-tests.json', checkedSource: 'before/projectName.mjs', matches: reports.candidate.sha256 === await hash('before/projectName.mjs') },
  changedFiles,
  knownLimits: ['Pure validation tests only; screenshots cover actual browser input handling separately.', 'No server-side validation, persistence, length rules, accessibility audit, Firefox, Safari, or mobile coverage.', 'A file hash catches accidental evidence mixups; it does not establish trusted provenance or reviewer acceptance.']
};
await writeFile('evidence/packet.json', JSON.stringify(packet, null, 2) + '\n');
console.log(JSON.stringify({ baseline: { passed: reports.before.passed, failed: reports.before.failed }, candidate: { passed: reports.candidate.passed, failed: reports.candidate.failed, sha256: reports.candidate.sha256 }, changedFiles: changedFiles.map(f=>f.file), testReportMatchesCandidate: packet.testReportMatchesCandidate, deliberateMismatchRejected: !packet.deliberateMismatch.matches }, null, 2));
