export function canSaveProjectName(raw) {
  return raw.length > 0;
}
