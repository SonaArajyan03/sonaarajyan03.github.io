import { mkdir, writeFile } from 'node:fs/promises';
const cases = [
  { name: 'empty name', input: '', expected: false },
  { name: 'ASCII spaces only', input: '   ', expected: false },
  { name: 'tabs and newline only', input: '\t\n', expected: false },
  { name: 'non-breaking space only', input: '\u00a0', expected: false },
  { name: 'plain name', input: 'Harbor', expected: true },
  { name: 'padded name', input: ' Harbor ', expected: true },
  { name: 'non-Latin name', input: '港', expected: true }
];
const html = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Project-name delivery evidence</title>
<style>body{margin:0;background:#edf1f6;color:#203048;font:18px/1.5 system-ui}main{width:840px;margin:50px auto;padding:36px;background:white;border:1px solid #c9d4e3;border-radius:16px}h1{font-size:30px;margin:0 0 10px}.note{color:#62738a;font-size:15px}label{display:block;margin-top:25px;font-weight:600}input{font:22px system-ui;padding:14px;border:2px solid #8fa5bf;border-radius:6px;width:90%}button{padding:12px 20px;font:16px system-ui;border:1px solid #8299b5;border-radius:6px;cursor:pointer;margin:10px 8px 0 0}#save{background:#245eae;color:white}#save:disabled{background:#aebdcd;cursor:default}.proof{font:14px ui-monospace;color:#5b6c83}</style>
<main><p class="note" id="snapshot"></p><h1>Name a project</h1><p>This local fixture compares the same dialog before and after a whitespace-validation fix.</p><label for="name">Project name</label><input id="name" aria-describedby="validation"><p id="validation" aria-live="polite"></p><button id="save">Save project</button><hr><button id="spaces">Use whitespace-only name</button><button id="normal">Use normal name</button><p class="proof" id="codepoints"></p><p class="note">No server, database, real project, or production account is involved.</p></main>
<script type="module">import { canSaveProjectName } from './projectName.mjs';
const input=document.querySelector('#name'),save=document.querySelector('#save'),validation=document.querySelector('#validation');
document.querySelector('#snapshot').textContent='DELIVERY-EVIDENCE FIXTURE · '+(location.pathname.includes('/candidate/')?'CANDIDATE SNAPSHOT':'BASELINE SNAPSHOT');
function update(){const valid=canSaveProjectName(input.value);save.disabled=!valid;validation.textContent=valid?'Save is available.':'Enter a name containing at least one non-whitespace character.';document.querySelector('#codepoints').textContent='Input codepoints: '+[...input.value].map(c=>'U+'+c.codePointAt(0).toString(16).toUpperCase().padStart(4,'0')).join(' ');}
input.addEventListener('input',update);document.querySelector('#spaces').onclick=()=>{input.value='   ';update();};document.querySelector('#normal').onclick=()=>{input.value='Harbor';update();};save.onclick=()=>{validation.textContent='Local demo only: this click does not create a project.';};update();</script></html>`;
for (const name of ['before', 'candidate']) {
  await mkdir(name, { recursive: true });
  await writeFile(`${name}/index.html`, html);
  await writeFile(`${name}/cases.json`, JSON.stringify(cases, null, 2) + '\n');
  const body = name === 'before' ? 'return raw.length > 0;' : 'return raw.trim().length > 0;';
  await writeFile(`${name}/projectName.mjs`, `export function canSaveProjectName(raw) {\n  ${body}\n}\n`);
}
console.log('Created baseline and candidate snapshots with seven shared cases.');
