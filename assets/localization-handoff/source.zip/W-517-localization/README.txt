W-517 localization handoff evidence

Purpose: an original, illustrative reward-panel fixture for a Tumblr text post.
This is not a captured game, a shipped fix, or a Wagglet integration.

Files
  index.html       Self-contained browser fixture; no dependencies/network fetches.
  strings.json     Source key, English string, candidate German wording, meaning.
  context-100.png  Actual Chrome screenshot of the fixture at normal label text size.
  context-130.png  Actual Chrome screenshot at 130% label text size.
  layout-checks.json  Actual DOM layout measures captured through CUA.

Reproduce
  Open index.html in a current browser.
  Change Text size between 100% and 130%.
  Both panels use a 320 x 200 CSS pixel container.
  The old button stays at 96px; its label is clipped at both sizes.
  The candidate uses content width, 160px minimum, 288px maximum, and wrapping.
  The candidate's actual measured widths were 169.90625px and 211.28125px.
  It was not clipped and stayed inside its panel at both text sizes.

Limits
  Larger text is a CSS label-font-size change, not OS scaling or browser zoom.
  Only this label, panel, and these two text sizes were checked.
  No mobile device, real game build, reward action, font substitution, other locale,
  screen-reader behavior, or translation quality was tested.
  Native German wording approval remains pending for any real game adoption.

Post image
  Attach context-130.png as the context image in the Tumblr text post.
  Alt text: Illustrative reward panel with the German candidate label Belohnung
  abholen at 130 percent label text size. The fixed 96-pixel button clips it;
  the content-width candidate shows the full label inside the same 320-pixel panel.

Human acceptance for a real project
  Designer confirms this is a reward collection action and approves layout hierarchy.
  Native German reviewer approves wording in context.
  Engineer reviews and executes a bounded change through their authorized tools.
  QA records actual build/device, reproduces original clipping, checks the candidate,
  and confirms the button still collects the intended reward.
  Producer records acceptance after reviewing that evidence; none is claimed here.
