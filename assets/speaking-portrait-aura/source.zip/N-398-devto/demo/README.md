# Speaking portrait aura in PixiJS

Node.js 20 or newer. Pinned versions: PixiJS 8.22.0, nixie-fx 0.1.20 and Vite 6.4.4.

```sh
npm ci
npm run vfx:validate
npm run vfx:export
npm run dev
```

Open `http://127.0.0.1:5199/`. The compiled export is already included.

The aura uses a four-particle halo emitter and a six-particle mote emitter. Both loop, but the host only advances the renderer while a speaker is active. A Pixi mask clips the aura to the portrait area. An opaque portrait and a separate opaque dialogue plate sit above the effect. No audio or lip sync is implemented.

`effects/speaking-portrait-aura.json` is the normalized authoring source generated with the official CLI and configured by `configure-effect.mjs`. `public/vfx` is the game-facing export. Edit the source and export again; do not patch compiled output.

## Verify

- Inspect at 1.00 seconds: observe the clipped aura behind the portrait and the unchanged dialogue text.
- Verify 120 frames of text: the ordinary ticker stops. The harness extracts the full scene's 540 × 100 body-text region with the aura off, then compares it against 120 fixed 1/60-second updates with the aura on. The crop includes the actual scene composition, not an isolated text container.
- Rowan speaks / Mira speaks: the portrait and speaker name change; one effect instance is reused.
- VFX off: the explicit Speaking label remains.
- Silence / Close dialogue: the aura is hidden and the ticker stops. Already allocated particles are retained in the paused instance. Resuming resets it, and final page teardown destroys the renderer and application.

The verification run found 2,798 bright foreground pixels in the reference crop, zero changed pixels across 120 frames, peak eight particles, capacity ten and one effect instance. Resource and unsupported-feature diagnostics were empty. These are local Chrome visual/lifecycle checks, not a mobile or performance benchmark. Pixel equality does not establish accessibility or readability at other sizes.

No unsupported settings are enabled. The effect uses unlit additive billboards. Lit shading requires the Three backend, and Pixi depthWrite uses draw ordering / ink rather than GPU depth-buffer writing. No material graphs, file textures, trails or sub-emitters are used. Real-editor visual review remains pending.
