import { Application, Container, Graphics, Rectangle, Text } from 'pixi.js';
import { loadVfxExportBundle } from 'nixie-fx/export';
import { PixiVfxRenderer, createPixiVfx2dProjection } from 'nixie-fx/pixi';
async function main() {
  const app = new Application();
  await app.init({width:900,height:430,background:'#172334',antialias:true,resolution:1,autoDensity:true});
  document.querySelector('#scene').appendChild(app.canvas); app.stop();
  const fetchJson = async url => {const r=await fetch(url);if(!r.ok)throw new Error(`${r.status}: ${url}`);return r.json();};
  const manifest = await fetchJson('/vfx/manifest.json');
  const effectsByPath = Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,await fetchJson(`/vfx/${e.path}`)])));
  const bundle = loadVfxExportBundle({manifest,effectsByPath,assetPaths:manifest.assets.map(a=>a.path)},{requiredBackend:'pixi2d',requiredEffectIds:['speaking-portrait-aura'],requireEveryAsset:true});
  const definition=bundle.effectsById.get('speaking-portrait-aura');
  const dialogue = new Container(); app.stage.addChild(dialogue);
  dialogue.addChild(new Graphics().rect(0,0,900,430).fill('#172334'));
  const label=(value,x,y,size,color,parent=dialogue)=>{const t=new Text({text:value,style:{fontFamily:'Arial',fontSize:size,fill:color}});t.position.set(x,y);parent.addChild(t);return t;};
  label('DIALOGUE · SPEAKING STATE',32,24,13,'#9bb1cc');
  label('The portrait can animate. The text stays still.',32,48,25,'#e6edf7');
  const aura = new Container(); aura.position.set(40,130); dialogue.addChild(aura);
  const clip = new Graphics().circle(110,110,96).fill('#ffffff'); clip.position.set(40,130); dialogue.addChild(clip); aura.mask=clip;
  const portrait = new Container(); portrait.position.set(40,130); dialogue.addChild(portrait);
  const portraitFace = new Graphics(); portrait.addChild(portraitFace);
  const plate = new Container(); dialogue.addChild(plate);
  plate.addChild(new Graphics().roundRect(270,150,580,190,14).fill('#203044').stroke({color:'#435a77',width:1}));
  const speakerLabel=label('ROWAN',292,170,18,'#b9e4ff',plate);
  const speakingLabel=label('Speaking',760,172,14,'#a9dcb4',plate);
  label('The east gate is still open.\nTake the lantern, then follow the river.',292,222,21,'#e6edf7',plate);
  label('Visual cue only. The explicit speaking label remains when VFX are off.',32,384,15,'#a1b8d3');
  const renderer=new PixiVfxRenderer({parent:aura,projection:createPixiVfx2dProjection({originX:110,originY:110,pixelsPerUnit:80,yAxis:'up'})});
  const fx=renderer.createEffect(definition,{autoStart:false,seed:398});
  let speaker='rowan', closed=false, enabled=true, elapsed=0;
  const checks=[];
  function drawPortrait() {
    const mira=speaker==='mira'; portraitFace.clear();
    portraitFace.circle(110,110,64).fill(mira?'#344c68':'#314a4e').stroke({color:'#8ca8c5',width:2});
    portraitFace.circle(110,105,31).fill(mira?'#d7b69c':'#cab89e');
    portraitFace.roundRect(76,140,68,27,12).fill(mira?'#937da9':'#719899');
    portraitFace.poly([79,89,86,67,112,65,140,82,139,104,125,90,103,94]).fill(mira?'#43445d':'#50463b');
    portraitFace.circle(99,104,2.5).circle(122,104,2.5).fill('#293449');
    speakerLabel.text=speaker?speaker.toUpperCase():'NO SPEAKER'; speakingLabel.text=speaker?'Speaking':'Silent';
  }
  function setSpeaker(next) {
    speaker=next; drawPortrait(); elapsed=0; fx.stop();
    aura.visible=Boolean(speaker)&&enabled&&!closed;
    if(aura.visible)fx.reset({seed:398});
  }
  function state(){const s=renderer.stats;return {speaker,enabled,closed,elapsed:+elapsed.toFixed(3),activeParticles:s.activeParticles,effectCount:s.effectCount,capacity:s.capacity,missingTextureRefs:s.missingTextureRefs,missingMaterialRefs:s.missingMaterialRefs,missingSubEmitterRefs:s.missingSubEmitterRefs,unsupportedModules:s.unsupportedModules,unsupportedFeatures:s.unsupportedFeatures,tickerStarted:app.ticker.started};}
  function report(){document.querySelector('#stats').textContent=JSON.stringify({state:state(),checks},null,2);}
  app.ticker.add(ticker=>{if(aura.visible){renderer.update(ticker.deltaMS/1000);elapsed+=ticker.deltaMS/1000;}report();});
  const message=document.querySelector('#message');
  for(const name of ['rowan','mira'])document.querySelector(`#${name}`).onclick=()=>{setSpeaker(name);if(!closed)app.start();message.textContent=`${name} is speaking.`;report();};
  document.querySelector('#silence').onclick=()=>{app.stop();setSpeaker(null);app.render();message.textContent='No active speaker: aura hidden and ticker stopped.';checks.push({check:'silence',...state()});report();};
  document.querySelector('#vfx-off').onclick=()=>{enabled=!enabled;app.stop();setSpeaker(speaker??'rowan');document.querySelector('#vfx-off').textContent=enabled?'VFX off':'VFX on';app.render();message.textContent='The explicit speaking label does not depend on the aura.';checks.push({check:'VFX preference',...state()});report();};
  document.querySelector('#freeze').onclick=()=>{app.stop();setSpeaker(speaker??'rowan');for(let i=0;i<60;i++){renderer.update(1/60);elapsed+=1/60;}app.render();message.textContent='Paused at 1.00 seconds.';report();};
  document.querySelector('#close').onclick=()=>{closed=!closed;app.stop();fx.stop();dialogue.visible=!closed;document.querySelector('#close').textContent=closed?'Open dialogue':'Close dialogue';for(const id of ['rowan','mira','silence','vfx-off','freeze','verify'])document.querySelector(`#${id}`).disabled=closed;checks.push({check:'dialogue visibility',...state()});app.render();report();};
  const textRegion=new Rectangle(292,222,540,100);
  const pixels=()=>app.renderer.extract.pixels({target:app.stage,frame:textRegion,resolution:1,antialias:true}).pixels;
  document.querySelector('#verify').onclick=async()=>{
    const button=document.querySelector('#verify');button.disabled=true;app.stop();setSpeaker('rowan');aura.visible=false;app.render();
    const reference=pixels().slice();let foreground=0;
    for(let i=0;i<reference.length;i+=4)if(reference[i]>180&&reference[i+1]>180&&reference[i+2]>180)foreground++;
    aura.visible=true;fx.reset({seed:398});elapsed=0;let maxChangedPixels=0,peakParticles=0;
    for(let frame=0;frame<120;frame++){
      renderer.update(1/60);elapsed+=1/60;peakParticles=Math.max(peakParticles,renderer.stats.activeParticles);
      const sample=pixels();let changed=0;for(let i=0;i<reference.length;i+=4)if(sample[i]!==reference[i]||sample[i+1]!==reference[i+1]||sample[i+2]!==reference[i+2]||sample[i+3]!==reference[i+3])changed++;
      maxChangedPixels=Math.max(maxChangedPixels,changed);
      if(frame%8===7)await new Promise(resolve=>requestAnimationFrame(resolve));
    }
    checks.push({check:'120 fixed-step text-region comparisons',region:[292,222,540,100],frames:120,foregroundPixels:foreground,maxChangedPixels,peakParticles,passed:foreground>300&&maxChangedPixels===0,versions:{pixi:'8.22.0',nixieFx:'0.1.20'}});
    app.render();button.disabled=false;message.textContent='Text comparison complete. This is a pixel-isolation check, not an accessibility or performance benchmark.';report();
  };
  document.addEventListener('visibilitychange',()=>{if(document.hidden)app.stop();});
  window.addEventListener('pagehide',()=>{app.stop();renderer.destroy();app.destroy(true,{children:true});});
  setSpeaker('rowan');app.render();message.textContent='Ready. Inspect a fixed frame or run the text comparison.';report();
}
main().catch(error=>{document.querySelector('#message').textContent=`Demo error: ${error.message}`;console.error(error);});
